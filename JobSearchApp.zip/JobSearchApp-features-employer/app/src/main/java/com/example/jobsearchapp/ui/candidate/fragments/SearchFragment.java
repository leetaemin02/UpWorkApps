package com.example.jobsearchapp.ui.candidate.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.jobsearchapp.R;
import com.example.jobsearchapp.data.local.AppDatabase;
import com.example.jobsearchapp.data.models.Job;
import com.example.jobsearchapp.ui.base.BaseFragment;
import com.example.jobsearchapp.ui.candidate.adapters.JobAdapter;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import java.util.List;

public class SearchFragment extends BaseFragment {
    
    private RecyclerView rvSearchResults;
    private JobAdapter adapter;
    private EditText edtSearch;
    private TextView tvResultCount, tvSort;
    private String currentTypeFilter = null;
    private String initialQuery = null;

    @Override
    protected int getLayoutId() {
        return R.layout.candidate_fragment_search;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            initialQuery = getArguments().getString("SEARCH_QUERY");
        }
    }

    @Override
    protected void initViews(View view) {
        rvSearchResults = view.findViewById(R.id.rvSearchResults);
        edtSearch = view.findViewById(R.id.edtSearch);
        tvResultCount = view.findViewById(R.id.tvResultCount);
        tvSort = view.findViewById(R.id.tvSort);
        
        setupRecyclerView();
        setupChips(view);

        if (initialQuery != null && edtSearch != null) {
            edtSearch.setText(initialQuery);
            performSearch();
        }
    }

    private void setupChips(View view) {
        ChipGroup chipGroup = view.findViewById(R.id.chipGroup);
        if (chipGroup != null) {
            chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
                if (checkedIds.isEmpty()) {
                    currentTypeFilter = null;
                } else {
                    Chip chip = group.findViewById(checkedIds.get(0));
                    if (chip != null) {
                        currentTypeFilter = chip.getText().toString();
                    }
                }
                performSearch();
            });
        }
    }

    private void performSearch() {
        if (adapter != null && edtSearch != null) {
            String query = edtSearch.getText().toString();
            adapter.filter(query, currentTypeFilter);
            updateResultCount(adapter.getItemCount());
        }
    }

    @Override
    protected void initListeners() {
        if (edtSearch != null) {
            edtSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch();
                }
                @Override
                public void afterTextChanged(Editable s) {}
            });
        }

        if (tvSort != null) {
            tvSort.setOnClickListener(v -> showSortMenu());
        }
    }

    private void showSortMenu() {
        PopupMenu popup = new PopupMenu(getContext(), tvSort);
        popup.getMenu().add("Mới nhất");
        popup.getMenu().add("Cũ nhất");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            tvSort.setText(title + " ▼");
            if (adapter != null) {
                adapter.sort(title.equals("Mới nhất"));
            }
            return true;
        });
        popup.show();
    }

    private void updateResultCount(int count) {
        if (tvResultCount != null) {
            tvResultCount.setText("Tìm thấy " + count + " kết quả");
        }
    }

    private void setupRecyclerView() {
        List<Job> jobs = AppDatabase.getInstance(getContext()).jobDao().getAllJobs();

        adapter = new JobAdapter(jobs);
        rvSearchResults.setLayoutManager(new LinearLayoutManager(getContext()));
        rvSearchResults.setAdapter(adapter);
        updateResultCount(adapter.getItemCount());
    }
}